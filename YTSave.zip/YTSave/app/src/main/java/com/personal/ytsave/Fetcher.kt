package com.personal.ytsave

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/** تحميل سريع: الملف يُقسم إلى أجزاء 4MB وتُحمّل 6 أجزاء بالتوازي */
object Fetcher {
    const val USER_AGENT_WEB =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
    private const val THREADS = 6
    private const val CHUNK = 4L * 1024 * 1024

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .dispatcher(Dispatcher().apply { maxRequests = 64; maxRequestsPerHost = 16 })
        .connectionPool(ConnectionPool(THREADS + 2, 5, TimeUnit.MINUTES))
        .build()

    private fun ua(url: String): String = when {
        url.contains("c=IOS") -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
        url.contains("c=ANDROID") -> "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
        else -> USER_AGENT_WEB
    }

    /** يرجع الحجم الكلي بالبايت */
    fun probe(url: String): Long {
        val req = Request.Builder().url(url).header("User-Agent", ua(url)).header("Range", "bytes=0-0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
            return total ?: throw IOException("تعذر تحديد حجم الملف")
        }
    }

    fun download(url: String, file: java.io.File, total: Long, done: AtomicLong) {
        val count = ((total + CHUNK - 1) / CHUNK).toInt()
        val next = AtomicInteger(0)
        val error = AtomicReference<Throwable?>(null)
        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(total)
            val ch = raf.channel
            val workers = (1..minOf(THREADS, count)).map {
                thread(name = "dl-worker") {
                    val buf = ByteArray(64 * 1024)
                    while (error.get() == null) {
                        if (DownloadService.cancel) { error.compareAndSet(null, Cancelled()); return@thread }
                        val i = next.getAndIncrement()
                        if (i >= count) break
                        val start = i * CHUNK
                        val end = minOf(total - 1, start + CHUNK - 1)
                        try {
                            fetchChunk(url, start, end, ch, buf, done)
                        } catch (e: Exception) {
                            error.compareAndSet(null, e)
                            return@thread
                        }
                    }
                }
            }
            workers.forEach { it.join() }
        }
        error.get()?.let { throw it }
    }

    private fun waitIfPaused() {
        while (DownloadService.paused && !DownloadService.cancel) {
            try { Thread.sleep(150) } catch (_: InterruptedException) {}
        }
    }

    /** يحمّل جزءاً كاملاً؛ يتوقف عند الإيقاف المؤقت ويكمل من نفس المكان، ويعيد المحاولة عند انقطاع الشبكة */
    private fun fetchChunk(url: String, start: Long, end: Long, ch: FileChannel, buf: ByteArray, done: AtomicLong) {
        val pos = longArrayOf(start)
        var attempt = 0
        while (pos[0] <= end) {
            waitIfPaused()
            if (DownloadService.cancel) throw Cancelled()
            val before = pos[0]
            try {
                readFrom(url, end, ch, buf, done, pos)
                if (pos[0] > before) attempt = 0
            } catch (e: Cancelled) {
                throw e
            } catch (e: Exception) {
                if (pos[0] > before) attempt = 0
                if (++attempt >= 4) throw e
                try { Thread.sleep(600) } catch (_: InterruptedException) {}
            }
        }
    }

    private fun readFrom(url: String, end: Long, ch: FileChannel, buf: ByteArray, done: AtomicLong, pos: LongArray) {
        val from = pos[0]
        val req = Request.Builder().url(url).header("User-Agent", ua(url))
            .header("Range", "bytes=$from-$end").build()
        client.newCall(req).execute().use { r ->
            if (r.code != 206 && !(r.code == 200 && from == 0L)) throw IOException("HTTP ${r.code}")
            val src = (r.body ?: throw IOException("empty body")).byteStream()
            while (pos[0] <= end) {
                if (DownloadService.cancel) throw Cancelled()
                if (DownloadService.paused) return   // نغلق الاتصال ونكمل لاحقاً
                val n = src.read(buf, 0, minOf(buf.size.toLong(), end - pos[0] + 1).toInt())
                if (n < 0) throw IOException("انقطع الاتصال")
                val bb = ByteBuffer.wrap(buf, 0, n)
                var p = pos[0]
                while (bb.hasRemaining()) p += ch.write(bb, p)
                pos[0] += n
                done.addAndGet(n.toLong())
            }
        }
    }
}
