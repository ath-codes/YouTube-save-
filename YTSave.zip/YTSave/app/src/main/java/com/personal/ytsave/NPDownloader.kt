package com.personal.ytsave

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException

/** يربط مكتبة NewPipeExtractor بالإنترنت عبر OkHttp */
class NPDownloader(private val client: OkHttpClient) : Downloader() {

    override fun execute(request: Request): Response {
        val method = request.httpMethod()
        val url = request.url()
        var body = request.dataToSend()?.toRequestBody()
        if (body == null && (method == "POST" || method == "PUT")) body = ByteArray(0).toRequestBody()

        val b = okhttp3.Request.Builder().method(method, body).url(url)
            .header("User-Agent", Fetcher.USER_AGENT_WEB)
        for ((name, values) in request.headers()) {
            b.removeHeader(name)
            for (v in values) b.addHeader(name, v)
        }

        val resp = client.newCall(b.build()).execute()
        if (resp.code == 429) {
            resp.close()
            throw ReCaptchaException("reCaptcha Challenge requested", url)
        }
        val text = resp.body?.string()
        val finalUrl = resp.request.url.toString()
        return Response(resp.code, resp.message, resp.headers.toMultimap(), text, finalUrl)
    }
}
