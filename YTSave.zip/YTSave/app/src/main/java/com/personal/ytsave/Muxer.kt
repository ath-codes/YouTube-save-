package com.personal.ytsave

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import java.io.File
import java.io.FileDescriptor
import java.io.IOException
import java.nio.ByteBuffer

/** دمج مسار الفيديو مع مسار الصوت في ملف MP4 واحد بدون إعادة ترميز (سريع جداً) */
object Muxer {

    private fun findTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        throw IOException("لم يتم العثور على المسار ($prefix)")
    }

    fun mux(videoFile: File, audioFile: File, out: FileDescriptor) {
        val ve = MediaExtractor()
        val ae = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ve.setDataSource(videoFile.path)
            ae.setDataSource(audioFile.path)
            val vt = findTrack(ve, "video/")
            val at = findTrack(ae, "audio/")
            ve.selectTrack(vt)
            ae.selectTrack(at)

            muxer = MediaMuxer(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val vOut = muxer.addTrack(ve.getTrackFormat(vt))
            val aOut = muxer.addTrack(ae.getTrackFormat(at))
            muxer.start()
            started = true

            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var vTime = ve.sampleTime
            var aTime = ae.sampleTime

            while (vTime >= 0 || aTime >= 0) {
                if (DownloadService.cancel) throw Cancelled()
                val useVideo = if (vTime < 0) false else if (aTime < 0) true else vTime <= aTime
                val ex = if (useVideo) ve else ae
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) {
                    if (useVideo) vTime = -1 else aTime = -1
                    continue
                }
                info.set(0, size, ex.sampleTime, ex.sampleFlags)
                muxer.writeSampleData(if (useVideo) vOut else aOut, buf, info)
                ex.advance()
                if (useVideo) vTime = ex.sampleTime else aTime = ex.sampleTime
            }
        } finally {
            try { if (started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            ve.release()
            ae.release()
        }
    }
}
