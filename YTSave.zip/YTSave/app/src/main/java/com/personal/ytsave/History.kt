package com.personal.ytsave

import android.content.Context

/** سجلّ الفيديوهات التي اكتمل تحميلها (يبقى محفوظاً بعد إغلاق التطبيق) */
object History {
    private const val PREF = "history"
    private const val KEY = "done"
    private const val MAX = 500

    private val urlRx = Regex("https?://\\S+")
    private val idRx = Regex("(?:youtu\\.be/|[?&]v=|/(?:shorts|embed|live|v)/)([A-Za-z0-9_-]{11})")

    /** معرّف الفيديو من أي نص فيه رابط، فيُعتبر youtu.be وyoutube.com ورابط المشاركة (si=) رابطاً واحداً */
    fun key(text: String): String? {
        val url = urlRx.find(text)?.value ?: return null
        return idRx.find(url)?.groupValues?.get(1) ?: url
    }

    @Synchronized
    fun has(ctx: Context, key: String): Boolean = load(ctx).contains(key)

    @Synchronized
    fun add(ctx: Context, key: String) {
        val list = load(ctx).toMutableList()
        list.remove(key)
        list.add(key)
        val kept = if (list.size > MAX) list.takeLast(MAX) else list
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, kept.joinToString("\n")).apply()
    }

    private fun load(ctx: Context): List<String> =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, "").orEmpty().split('\n').filter { it.isNotEmpty() }
}
