package com.personal.ytsave

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.exceptions.ContentNotAvailableException
import org.schabi.newpipe.extractor.exceptions.ExtractionException
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

class DownloadService : Service() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_AUDIO = "audio"
        private const val CH = "dl"
        private const val NID = 1

        @Volatile var busy = false
        @Volatile var cancel = false
        @Volatile var paused = false
        @Volatile var lastUri: Uri? = null
        @Volatile var lastMime: String = ""
        @Volatile var lastAudio = false
        @Volatile var last = Status("", -1, false, 0)
        @Volatile var listener: ((Status) -> Unit)? = null
        private val main = Handler(Looper.getMainLooper())
        private var inited = false

        fun publish(s: Status) {
            last = s
            main.post { listener?.invoke(s) }
        }
    }

    private lateinit var nm: NotificationManager
    @Volatile private var curTitle = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "التحميل", NotificationManager.IMPORTANCE_LOW))
        startForeground(NID, notif("جارٍ التحضير...", -1, true, null), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        val url = intent?.getStringExtra(EXTRA_URL)
        val audioOnly = intent?.getBooleanExtra(EXTRA_AUDIO, false) ?: false
        if (url == null) { stopSelf(); return START_NOT_STICKY }
        if (busy) return START_NOT_STICKY

        busy = true
        curTitle = ""
        cancel = false
        paused = false
        lastUri = null
        thread(name = "dl-main") {
            var pi: PendingIntent? = null
            val st: Status = try {
                val (uri, mime) = work(url, audioOnly)
                pi = viewIntent(uri, mime)
                lastMime = mime
                lastAudio = audioOnly
                lastUri = uri
                Status("✓ تم الحفظ", 100, false, 1, curTitle, note = "📁 ${if (audioOnly) "Music/YTSave" else "Movies/YTSave"}")
            } catch (e: Cancelled) {
                Status("تم الإلغاء", 0, false, 0, curTitle)
            } catch (e: Throwable) {
                Status("⚠ تعذّر التحميل", 0, false, 2, curTitle, note = friendly(e))
            }
            busy = false
            paused = false
            publish(st)
            stopForeground(STOP_FOREGROUND_DETACH)
            nm.notify(NID, notif(listOf(st.text, st.note).filter { it.isNotEmpty() }.joinToString(" • "), 100, false, pi))
            stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------------- العمل الرئيسي ----------------

    private fun work(url: String, audioOnly: Boolean): Pair<Uri, String> {
        val v = File(cacheDir, "v.tmp")
        val a = File(cacheDir, "a.tmp")
        v.delete(); a.delete()
        try {
            post("جارٍ جلب معلومات الفيديو...", -1)
            if (!inited) {
                NewPipe.init(NPDownloader(Fetcher.client), Localization("en", "US"), ContentCountry("US"))
                inited = true
            }
            val info = StreamInfo.getInfo(url)
            val title = clean(info.name)
            curTitle = info.name ?: ""
            val audio = pickAudio(info.audioStreams)

            if (audioOnly) {
                val s = audio ?: throw IOException("لا يوجد مسار صوتي لهذا الفيديو")
                val len = Fetcher.probe(s.content)
                download(listOf(Triple(s.content, a, len)), "تحميل الصوت")
                post("جارٍ الحفظ...", -1)
                val mime = s.format?.mimeType ?: "audio/mp4"
                val ext = s.format?.suffix ?: "m4a"
                return Pair(saveFile(a, "$title.$ext", mime, true), mime)
            }

            val vs = pickVideo(info)
            if (vs != null && audio != null && audio.format == MediaFormat.M4A) {
                val vl = Fetcher.probe(vs.content)
                val al = Fetcher.probe(audio.content)
                download(listOf(Triple(vs.content, v, vl), Triple(audio.content, a, al)), "تحميل ${vs.height}p")
                post("جارٍ دمج الصورة والصوت...", -1)
                val uri = newItem("$title.mp4", "video/mp4", false)
                try {
                    contentResolver.openFileDescriptor(uri, "rw")!!.use { pfd -> Muxer.mux(v, a, pfd.fileDescriptor) }
                    finishItem(uri)
                } catch (e: Throwable) {
                    contentResolver.delete(uri, null, null)
                    throw e
                }
                return Pair(uri, "video/mp4")
            }

            // خطة بديلة: فيديو جاهز بصوت (جودة أقل)
            val p = info.videoStreams
                .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.format == MediaFormat.MPEG_4 }
                .maxByOrNull { it.height } ?: throw IOException("لا توجد صيغة فيديو مناسبة")
            val pl = Fetcher.probe(p.content)
            download(listOf(Triple(p.content, v, pl)), "تحميل ${p.height}p")
            post("جارٍ الحفظ...", -1)
            return Pair(saveFile(v, "$title.mp4", "video/mp4", false), "video/mp4")
        } finally {
            v.delete(); a.delete()
        }
    }

    private fun pickAudio(list: List<AudioStream>): AudioStream? {
        val direct = list.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val orig = direct.filter { it.audioTrackType == null || it.audioTrackType == AudioTrackType.ORIGINAL }
        val pool = if (orig.isNotEmpty()) orig else direct
        val m4a = pool.filter { it.format == MediaFormat.M4A }
        return (if (m4a.isNotEmpty()) m4a else pool).maxByOrNull { it.averageBitrate }
    }

    /** أعلى جودة بصيغة H.264 داخل MP4 (الأكثر توافقاً مع الدمج والتشغيل) */
    private fun pickVideo(info: StreamInfo): VideoStream? =
        info.videoOnlyStreams
            .filter {
                it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP &&
                    it.format == MediaFormat.MPEG_4 &&
                    it.codec?.startsWith("avc1") == true
            }
            .maxWithOrNull(compareBy<VideoStream>({ it.height }, { it.fps }))

    // ---------------- التحميل مع عرض السرعة ----------------

    private fun download(items: List<Triple<String, File, Long>>, label: String) {
        val total = items.sumOf { it.third }
        val done = AtomicLong(0)
        val on = AtomicBoolean(true)
        val ticker = thread(name = "dl-tick") {
            var lastBytes = 0L
            var lastT = System.nanoTime()
            var speed = 0.0
            while (on.get()) {
                try { Thread.sleep(400) } catch (_: InterruptedException) { break }
                val d = done.get()
                val t = System.nanoTime()
                val pct = if (total > 0) (d * 100 / total).toInt().coerceIn(0, 99) else 0
                val size = sizePair(d, total)
                if (paused) {
                    speed = 0.0; lastBytes = d; lastT = t
                    progress("⏸ متوقف مؤقتاً", pct, "—", size, "—", "⏸ متوقف مؤقتاً  $pct%")
                } else {
                    val inst = (d - lastBytes) * 1e9 / (t - lastT)
                    speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
                    lastBytes = d; lastT = t
                    val left = if (speed > 20_000 && total > d) fmtEta(((total - d) / speed).toLong()) else "—"
                    progress(label, pct, speedText(speed), size, left, "$label  $pct%  •  ${speedText(speed)}")
                }
            }
        }
        try {
            for ((u, f, l) in items) Fetcher.download(u, f, l, done)
        } finally {
            on.set(false)
            ticker.interrupt()
            ticker.join()
        }
    }

    // ---------------- الحفظ في المعرض / الموسيقى ----------------

    private fun newItem(name: String, mime: String, audio: Boolean): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music/YTSave" else "Movies/YTSave")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val col = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        return contentResolver.insert(col, values) ?: throw IOException("تعذر إنشاء الملف")
    }

    private fun finishItem(uri: Uri) {
        val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        contentResolver.update(uri, v, null, null)
    }

    private fun saveFile(src: File, name: String, mime: String, audio: Boolean): Uri {
        val uri = newItem(name, mime, audio)
        try {
            contentResolver.openOutputStream(uri)!!.use { out ->
                src.inputStream().use { it.copyTo(out, 256 * 1024) }
            }
            finishItem(uri)
        } catch (e: Throwable) {
            contentResolver.delete(uri, null, null)
            throw e
        }
        return uri
    }

    // ---------------- أدوات ----------------

    private fun clean(name: String?): String =
        (name ?: "").replace(Regex("[\\\\/:*?\"<>|\\r\\n]"), " ").trim().take(80).ifEmpty { "video" }

    private fun friendly(e: Throwable): String = when (e) {
        is ContentNotAvailableException -> "الفيديو غير متاح (خاص أو محذوف أو مقيّد)"
        is java.net.UnknownHostException, is java.net.SocketTimeoutException -> "تحقق من اتصال الإنترنت"
        is ExtractionException -> "تعذّر قراءة الفيديو — قد يحتاج التطبيق إلى تحديث"
        else -> e.message ?: e.javaClass.simpleName
    }

    private fun sizePair(d: Long, total: Long): String {
        val gb = total >= 1073741824L
        val div = if (gb) 1073741824.0 else 1048576.0
        val f = if (gb) "%.2f" else "%.1f"
        val loc = java.util.Locale.US
        return String.format(loc, "$f / $f %s", d / div, total / div, if (gb) "GB" else "MB")
    }

    private fun speedText(bps: Double): String =
        if (bps >= 1048576) String.format(java.util.Locale.US, "%.1f MB/s", bps / 1048576.0)
        else String.format(java.util.Locale.US, "%d KB/s", (bps / 1024).toLong())

    private fun fmtEta(sec: Long): String =
        if (sec >= 3600) String.format(java.util.Locale.US, "%d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
        else String.format(java.util.Locale.US, "%d:%02d", sec / 60, sec % 60)

    private fun progress(label: String, pct: Int, speed: String, size: String, eta: String, notifText: String) {
        publish(Status(label, pct, true, 0, curTitle, speed, size, eta))
        nm.notify(NID, notif(notifText, pct, true, null))
    }

    private fun post(text: String, pct: Int) {
        publish(Status(text, pct, true, 0, curTitle))
        nm.notify(NID, notif(text.replace("\n", " • "), pct, true, null))
    }

    private fun viewIntent(uri: Uri, mime: String): PendingIntent {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun notif(text: String, pct: Int, ongoing: Boolean, pi: PendingIntent?): Notification {
        val b = Notification.Builder(this, CH)
            .setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)
            .setContentTitle("تحميل يوتيوب")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
        if (ongoing) b.setProgress(100, maxOf(pct, 0), pct < 0)
        if (pi != null) b.setContentIntent(pi)
        return b.build()
    }
}
