package com.personal.ytsave

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var input: EditText
    private lateinit var btnVideo: Button
    private lateinit var btnAudio: Button
    private lateinit var btnCancel: Button
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar

    private val urlRx = Regex("https?://\\S+")
    private val ytRx = Regex("(youtube\\.com|youtu\\.be)", RegexOption.IGNORE_CASE)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat()
        setColor(color)
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun bigButton(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 20f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = shape(color, 22)
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(88)).apply { topMargin = dp(14) }
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(56), dp(22), dp(22))
            setBackgroundColor(0xFFF4F4F6.toInt())
        }
        root.addView(TextView(this).apply {
            text = "تحميل من يوتيوب"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF111111.toInt())
        })
        root.addView(TextView(this).apply {
            text = "ألصق الرابط أو شاركه من يوتيوب، ثم اختر النوع"
            textSize = 14f
            setTextColor(0xFF666666.toInt())
            setPadding(0, dp(6), 0, dp(18))
        })

        input = EditText(this).apply {
            hint = "رابط الفيديو"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            background = shape(Color.WHITE, 14, 0xFFDDDDDD.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        }
        root.addView(input)

        btnVideo = bigButton("🎬  فيديو — أعلى جودة", 0xFFE53935.toInt()) { start(false) }
        btnAudio = bigButton("🎧  صوت فقط", 0xFF1E88E5.toInt()) { start(true) }
        root.addView(btnVideo)
        root.addView(btnAudio)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(26) }
        }
        root.addView(bar)

        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(status)

        btnCancel = Button(this).apply {
            text = "إلغاء"
            isAllCaps = false
            visibility = View.GONE
            setOnClickListener {
                DownloadService.cancel = true
                status.text = "جارٍ الإلغاء..."
            }
        }
        root.addView(btnCancel)

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        urlRx.find(text)?.value?.let { input.setText(it) }
    }

    override fun onStart() {
        super.onStart()
        DownloadService.listener = { render(it) }
        render(DownloadService.last)
    }

    override fun onStop() {
        DownloadService.listener = null
        super.onStop()
    }

    /** لصق تلقائي لو كان في الحافظة رابط يوتيوب */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || input.text.isNotEmpty()) return
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val t = clip.getItemAt(0).text?.toString() ?: return
        urlRx.find(t)?.value?.takeIf { ytRx.containsMatchIn(it) }?.let { input.setText(it) }
    }

    private fun start(audio: Boolean) {
        val url = urlRx.find(input.text.toString())?.value
        if (url == null || !ytRx.containsMatchIn(url)) {
            Toast.makeText(this, "الصق رابط يوتيوب صحيح أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        if (DownloadService.busy) {
            Toast.makeText(this, "يوجد تحميل جارٍ", Toast.LENGTH_SHORT).show()
            return
        }
        render(Status("جارٍ التحضير...", -1, true, 0))
        startForegroundService(
            Intent(this, DownloadService::class.java)
                .putExtra(DownloadService.EXTRA_URL, url)
                .putExtra(DownloadService.EXTRA_AUDIO, audio)
        )
    }

    private fun render(s: Status) {
        status.text = s.text
        status.setTextColor(
            when (s.kind) {
                1 -> 0xFF2E7D32.toInt()
                2 -> 0xFFC62828.toInt()
                else -> 0xFF444444.toInt()
            }
        )
        bar.visibility = if (s.active) View.VISIBLE else View.GONE
        bar.isIndeterminate = s.percent < 0
        if (s.percent >= 0) bar.progress = s.percent
        btnCancel.visibility = if (s.active) View.VISIBLE else View.GONE
        btnVideo.isEnabled = !s.active
        btnAudio.isEnabled = !s.active
        btnVideo.alpha = if (s.active) 0.4f else 1f
        btnAudio.alpha = if (s.active) 0.4f else 1f
    }
}
