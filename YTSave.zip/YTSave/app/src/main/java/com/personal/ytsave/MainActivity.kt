package com.personal.ytsave

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private val C_BG = 0xFFF4F5F7.toInt()
private val C_DARK = 0xFF111827.toInt()
private val C_GRAY = 0xFF6B7280.toInt()
private val C_TRACK = 0xFFE5E7EB.toInt()
private val C_RED = 0xFFE53935.toInt()
private val C_BLUE = 0xFF1E88E5.toInt()
private val C_GREEN = 0xFF2E7D32.toInt()
private val C_AMBER = 0xFFF57C00.toInt()

class MainActivity : Activity() {

    private lateinit var input: EditText
    private lateinit var btnVideo: Button
    private lateinit var btnAudio: Button

    private lateinit var card: LinearLayout
    private lateinit var tvTitle: TextView
    private lateinit var tvStage: TextView
    private lateinit var tvPct: TextView
    private lateinit var bar: ProgressBar
    private lateinit var barFill: GradientDrawable
    private lateinit var statsRow: LinearLayout
    private lateinit var tvSpeed: TextView
    private lateinit var tvSize: TextView
    private lateinit var tvEta: TextView
    private lateinit var tvNote: TextView
    private lateinit var controls: LinearLayout
    private lateinit var btnPause: Button
    private lateinit var btnCancel: Button
    private lateinit var btnOpen: Button

    private val urlRx = Regex("https?://\\S+")
    private val ytRx = Regex("(youtube\\.com|youtu\\.be)", RegexOption.IGNORE_CASE)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat()
        setColor(color)
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private val pauseBg by lazy { shape(0xFFFFF3E0.toInt(), 16) }
    private val resumeBg by lazy { shape(0xFFE8F5E9.toInt(), 16) }

    private fun bigButton(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 20f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = shape(color, 22)
        stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(84)).apply { topMargin = dp(14) }
        setOnClickListener { onClick() }
    }

    private fun softButton(label: String, bg: GradientDrawable, fg: Int) = Button(this).apply {
        text = label
        textSize = 16f
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(fg)
        background = bg
        stateListAnimator = null
    }

    private fun divider() = View(this).apply { setBackgroundColor(C_TRACK) }

    private fun statColumn(caption: String): Pair<LinearLayout, TextView> {
        val act = this
        val value = TextView(act).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_DARK)
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
        }
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(TextView(act).apply {
                text = caption
                textSize = 12f
                setTextColor(C_GRAY)
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, dp(2))
            })
            addView(value)
        }
        return col to value
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(56), dp(22), dp(28))
        }
        root.addView(TextView(this).apply {
            text = "تحميل من يوتيوب"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_DARK)
        })
        root.addView(TextView(this).apply {
            text = "ألصق الرابط أو شاركه من يوتيوب، ثم اختر النوع"
            textSize = 14f
            setTextColor(C_GRAY)
            setPadding(0, dp(6), 0, dp(18))
        })

        input = EditText(this).apply {
            hint = "رابط الفيديو"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            background = shape(Color.WHITE, 14, 0xFFDDDDDD.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        }
        root.addView(input)

        btnVideo = bigButton("🎬  فيديو — أعلى جودة", C_RED) { start(false) }
        btnAudio = bigButton("🎧  صوت فقط", C_BLUE) { start(true) }
        root.addView(btnVideo)
        root.addView(btnAudio)

        buildCard(root)

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(C_BG)
            addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        handleIntent(intent)
    }

    /** بطاقة التقدم: العنوان ← الحالة والنسبة ← الشريط ← الإحصائيات ← الأزرار */
    private fun buildCard(root: LinearLayout) {
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(Color.WHITE, 22)
            elevation = dp(2).toFloat()
            setPadding(dp(18), dp(16), dp(18), dp(16))
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(22) }
        }

        tvTitle = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_DARK)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, 0, 0, dp(10))
        }
        card.addView(tvTitle)

        tvStage = TextView(this).apply {
            textSize = 14f
            setTextColor(C_GRAY)
            gravity = Gravity.CENTER_VERTICAL
        }
        tvPct = TextView(this).apply {
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_DARK)
            textDirection = View.TEXT_DIRECTION_LTR
        }
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(tvStage, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(tvPct, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        })

        barFill = GradientDrawable().apply { cornerRadius = dp(5).toFloat(); setColor(C_RED) }
        val track = GradientDrawable().apply { cornerRadius = dp(5).toFloat(); setColor(C_TRACK) }
        val clip = ClipDrawable(barFill, Gravity.START, ClipDrawable.HORIZONTAL)
        val layers = LayerDrawable(arrayOf(track, clip)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressDrawable = layers
            indeterminateTintList = ColorStateList.valueOf(C_RED)
        }
        card.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(10)).apply {
            topMargin = dp(8); bottomMargin = dp(16)
        })

        val (c1, v1) = statColumn("السرعة")
        val (c2, v2) = statColumn("الحجم")
        val (c3, v3) = statColumn("المتبقي")
        tvSpeed = v1; tvSize = v2; tvEta = v3
        statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            addView(c1, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(divider(), LinearLayout.LayoutParams(dp(1), dp(30)))
            addView(c2, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.5f))
            addView(divider(), LinearLayout.LayoutParams(dp(1), dp(30)))
            addView(c3, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        card.addView(statsRow)

        tvNote = TextView(this).apply {
            textSize = 14f
            setTextColor(C_GRAY)
            visibility = View.GONE
        }
        card.addView(tvNote)

        btnPause = softButton("⏸ إيقاف مؤقت", pauseBg, 0xFFE65100.toInt())
        btnPause.setOnClickListener {
            DownloadService.paused = !DownloadService.paused
            render(DownloadService.last)
        }
        btnCancel = softButton("✕ إلغاء", shape(0xFFFDECEA.toInt(), 16), 0xFFC62828.toInt())
        btnCancel.setOnClickListener {
            DownloadService.paused = false
            DownloadService.cancel = true
            tvStage.text = "جارٍ الإلغاء..."
        }
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            addView(btnPause, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
            addView(btnCancel, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        }
        card.addView(controls, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(18) })

        btnOpen = Button(this).apply {
            text = "📂  فتح المجلد"
            textSize = 17f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = shape(C_GREEN, 16)
            stateListAnimator = null
            visibility = View.GONE
            setOnClickListener { openFolder() }
        }
        card.addView(btnOpen, LinearLayout.LayoutParams(MATCH_PARENT, dp(56)).apply { topMargin = dp(14) })

        root.addView(card)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        urlRx.find(text)?.value?.let { input.setText(it) }
    }

    override fun onStart() {
        super.onStart()
        DownloadService.listener = { render(it) }
        render(DownloadService.last)
    }

    override fun onStop() {
        DownloadService.listener = null
        super.onStop()
    }

    /** لصق تلقائي لرابط يوتيوب جديد في الحافظة (يتجاهل الروابط التي سبق تحميلها) */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) autoPaste()
    }

    private fun autoPaste() {
        if (input.text.isNotEmpty()) return
        val cm = getSystemService(ClipboardManager::class.java)
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val t = clip.getItemAt(0).text?.toString() ?: return
        val url = urlRx.find(t)?.value?.takeIf { ytRx.containsMatchIn(it) } ?: return
        val key = History.key(url)
        if (key != null && History.has(this, key)) return
        input.setText(url)
    }

    private fun start(audio: Boolean) {
        val url = urlRx.find(input.text.toString())?.value
        if (url == null || !ytRx.containsMatchIn(url)) {
            Toast.makeText(this, "الصق رابط يوتيوب صحيح أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        if (DownloadService.busy) {
            Toast.makeText(this, "يوجد تحميل جارٍ", Toast.LENGTH_SHORT).show()
            return
        }
        render(Status("جارٍ التحضير...", -1, true, 0))
        startForegroundService(
            Intent(this, DownloadService::class.java)
                .putExtra(DownloadService.EXTRA_URL, url)
                .putExtra(DownloadService.EXTRA_AUDIO, audio)
        )
    }

    /** يفتح مجلد الحفظ في تطبيق الملفات؛ وإن لم يدعمه الهاتف يفتح الملف نفسه */
    private fun openFolder() {
        val rel = if (DownloadService.lastAudio) "Music/YTSave" else "Movies/YTSave"
        val dir = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:$rel")
        for (action in listOf("android.provider.action.BROWSE", Intent.ACTION_VIEW)) {
            try {
                startActivity(
                    Intent(action).setDataAndType(dir, DocumentsContract.Document.MIME_TYPE_DIR)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            } catch (_: Exception) { }
        }
        val u = DownloadService.lastUri
        try {
            if (u == null) throw IllegalStateException()
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(u, DownloadService.lastMime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (_: Exception) {
            Toast.makeText(this, "المجلد: $rel", Toast.LENGTH_LONG).show()
        }
    }

    private fun render(s: Status) {
        val idle = !s.active && s.text.isEmpty()
        card.visibility = if (idle) View.GONE else View.VISIBLE

        btnVideo.isEnabled = !s.active
        btnAudio.isEnabled = !s.active
        btnVideo.alpha = if (s.active) 0.4f else 1f
        btnAudio.alpha = if (s.active) 0.4f else 1f

        tvTitle.visibility = if (s.title.isEmpty()) View.GONE else View.VISIBLE
        tvTitle.text = s.title

        when {
            s.active -> {
                val hasPct = s.percent >= 0
                val paused = DownloadService.paused
                tvStage.text = s.text
                tvStage.setTextColor(if (paused) C_AMBER else C_GRAY)
                tvPct.visibility = if (hasPct) View.VISIBLE else View.GONE
                tvPct.text = "${s.percent}%"
                tvPct.setTextColor(C_DARK)
                bar.visibility = View.VISIBLE
                bar.isIndeterminate = !hasPct
                if (hasPct) bar.progress = s.percent
                barFill.setColor(if (paused) C_AMBER else C_RED)
                statsRow.visibility = if (hasPct) View.VISIBLE else View.GONE
                tvSpeed.text = s.speed.ifEmpty { "—" }
                tvSize.text = s.sizeLine.ifEmpty { "—" }
                tvEta.text = s.eta.ifEmpty { "—" }
                tvNote.visibility = View.GONE
                controls.visibility = View.VISIBLE
                btnPause.visibility = if (hasPct) View.VISIBLE else View.GONE
                if (paused) {
                    btnPause.text = "▶ استكمال"
                    btnPause.background = resumeBg
                    btnPause.setTextColor(C_GREEN)
                } else {
                    btnPause.text = "⏸ إيقاف مؤقت"
                    btnPause.background = pauseBg
                    btnPause.setTextColor(0xFFE65100.toInt())
                }
                btnOpen.visibility = View.GONE
            }
            s.kind == 1 -> {
                // اكتمل التحميل: أفرغ الخانة إن كانت ما تزال تحمل الرابط نفسه، ثم الصق الجديد إن وُجد
                val done = DownloadService.lastDoneKey
                if (done != null && History.key(input.text.toString()) == done) {
                    input.setText("")
                    if (hasWindowFocus()) autoPaste()
                }
                tvStage.text = s.text
                tvStage.setTextColor(C_GREEN)
                tvPct.visibility = View.GONE
                bar.visibility = View.VISIBLE
                bar.isIndeterminate = false
                bar.progress = 100
                barFill.setColor(C_GREEN)
                statsRow.visibility = View.GONE
                tvNote.text = s.note
                tvNote.visibility = if (s.note.isEmpty()) View.GONE else View.VISIBLE
                controls.visibility = View.GONE
                btnOpen.visibility = if (DownloadService.lastUri != null) View.VISIBLE else View.GONE
            }
            s.kind == 2 -> {
                tvStage.text = s.text
                tvStage.setTextColor(0xFFC62828.toInt())
                tvPct.visibility = View.GONE
                bar.visibility = View.GONE
                statsRow.visibility = View.GONE
                tvNote.text = s.note
                tvNote.visibility = if (s.note.isEmpty()) View.GONE else View.VISIBLE
                controls.visibility = View.GONE
                btnOpen.visibility = View.GONE
            }
            else -> {
                tvStage.text = s.text
                tvStage.setTextColor(C_GRAY)
                tvPct.visibility = View.GONE
                bar.visibility = View.GONE
                statsRow.visibility = View.GONE
                tvNote.visibility = View.GONE
                controls.visibility = View.GONE
                btnOpen.visibility = View.GONE
            }
        }
    }
}
