package com.personal.ytsave

import java.io.IOException

/** kind: 0 = معلومة، 1 = نجاح، 2 = خطأ */
data class Status(val text: String, val percent: Int, val active: Boolean, val kind: Int)

class Cancelled : IOException("cancelled")
