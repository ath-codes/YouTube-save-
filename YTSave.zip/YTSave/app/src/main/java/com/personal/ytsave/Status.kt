package com.personal.ytsave

import java.io.IOException

/**
 * kind: 0 = معلومة، 1 = نجاح، 2 = خطأ
 * text = سطر الحالة، title = عنوان الفيديو، speed/sizeLine/eta = إحصائيات التحميل، note = تفاصيل إضافية
 */
data class Status(
    val text: String,
    val percent: Int,
    val active: Boolean,
    val kind: Int,
    val title: String = "",
    val speed: String = "",
    val sizeLine: String = "",
    val eta: String = "",
    val note: String = ""
)

class Cancelled : IOException("cancelled")
