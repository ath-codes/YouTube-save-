# YTSave — تحميل يوتيوب (فيديو / صوت)

- Kotlin بدون مكتبات واجهة ثقيلة (Views برمجية) — minSdk 29 (أندرويد 10+)
- الاستخراج: NewPipeExtractor v0.26.5 (JitPack) + OkHttp
- الصوت: أفضل m4a مباشرة → Music/YTSave
- الفيديو: أعلى جودة H.264/MP4 (فيديو + صوت منفصلين) ثم دمج بـ MediaMuxer → Movies/YTSave
- التحميل: Range chunks 4MB × 6 اتصالات متوازية (Fetcher.kt)
- المشاركة من يوتيوب: intent-filter ACTION_SEND text/plain
- لو تعطل التحميل فجأة: غالباً يحتاج رفع نسخة NewPipeExtractor في app/build.gradle.kts
- لو تعطل التطبيق بعد التثبيت: جرّب isMinifyEnabled = false
